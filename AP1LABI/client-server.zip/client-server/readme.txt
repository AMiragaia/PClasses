Trabalho de aprofundamento no âmbito da disciplina de Laboratórios de Informática 
André Miragaia Rodrigues(108412) 50%
André Filipe Gomes Cruz(110554) 50%

Notas importantes:

No ficheiro client_com_menu.py foi implementado um menu interativo através do modulo tkinter.
O ficheiro pode ser executado normalmente pelo terminal, ou através do executavél disponivél na pasta.
Lá estão implentadas todas as funções esperadas pelo professor, apenas estão fundidas com o menu.
Pode encontrar a source sem menu no client.py.
O utilizador tem total liberdade de escolher se quer interagir com o servidor de forma encriptada ou não.

Para fazer os testes, é necessário que o servidor esteja a correr na porta 8888.
Para fazer a encriptação foi usado o modulo pycrypto.

